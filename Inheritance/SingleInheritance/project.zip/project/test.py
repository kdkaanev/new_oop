from project.animal import Animal

dog = Dog()
print(dog.bark())
print(dog.eat())